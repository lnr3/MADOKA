#ifndef WRITEFILE_H
#define WRITEFILE_H

#include "basic.h"
#include "residue.h"

template <typename ForwardIterator>
void write_result(const char *file, const string &remark, ForwardIterator begin, ForwardIterator end)
{
    ofstream output(file, std::ios::app);
    if (!output) throw std::runtime_error("file writing failed");

    output << remark << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
        output << iterator->first;
    output << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
    {
        if (iterator->first == '-' || iterator->second == '-')
            output << ' ';
        else
            output << '|';
    }
    output << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
        output << iterator->second;
    output << "\n\n";
    output.close();
}

template <typename T, typename ForwardIterator>
void write_residue(const char *file, const string &f1, const string &f2,
                   ForwardIterator begin1, ForwardIterator end1, ForwardIterator begin2, ForwardIterator end2)
{
    ofstream output(file, std::ios::app);
    if (!output) throw std::runtime_error("file writing failed");

    output << f1 << " as template structure\n";
    int i = 0;
    output << std::fixed;
    output.precision(3);
    output << std::showpoint;
    for (auto iterator = begin1; iterator != end1; ++iterator)
    {
        output << "ATOM" << std::setw(7) << ++i << "  CA" << "  " << AAmap(iterator->kind) << " A" << std::setw(4) << i;
        output << "    ";
        output << std::setw(8) << iterator->operator[](0);
        output << std::setw(8) << iterator->operator[](1);
        output << std::setw(8) << iterator->operator[](2) << '\n';
    }

    output << "\n\n";
    output << f2 <<  " as constant structure\n";
    i = 0;
    for (auto iterator = begin2; iterator != end2; ++iterator)
    {
        output << "ATOM" << std::setw(7) << ++i << "  CA" << "  " << AAmap(iterator->kind) << " A" << std::setw(4) << i;
        output << "    ";
        output << std::setw(8) << iterator->operator[](0);
        output << std::setw(8) << iterator->operator[](1);
        output << std::setw(8) << iterator->operator[](2) << '\n';
    }
    output.close();
}

#endif // WRITEFILE_H
