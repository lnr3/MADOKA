#include "initial.h"

bool first_phase(const string &A, const string &B, const char *p, const char *q, const string &file)
{
    int x = A.size(), y = B.size();
    Matrix<int> score(x + 1, y + 1);
    int value = structure_dp(score, A.cbegin(), A.cend(), B.cbegin(), B.cend());

    // LCS
    vector<pair<char, char>> ss_ali;
    ss_ali.reserve(space);
    structure_alignment(score, '-', A.cbegin(), A.cend(), B.cbegin(), B.cend(), std::back_inserter(ss_ali));
    int threshold = std::min(A.size(), B.size()) * 0.7;

    string remark = "Similarity value of secondary structure elements is " + to_string(value) + " and the threshold is " + to_string(threshold);
    write_result(file.data(), remark, ss_ali.crbegin(), ss_ali.crend());

    return threshold < value;   // continue to the accurate alignment?
}
