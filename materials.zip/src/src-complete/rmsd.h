#ifndef RMSD_H
#define RMSD_H

#include "residue.h"

template <typename T, typename RandomAccessIterator>
T rmsd(RandomAccessIterator joint, RandomAccessIterator constant, const vector<pair<int, int>> &connect, int target)
{
    T score = 0;
	unsigned int k = 0;
    for (unsigned long long i = 0, j = connect.size(); i != j; ++i)
    {
        if (connect[i].first != -1 && connect[i].second != -1)
        {
            T x = joint[connect[i].first][0] - constant[connect[i].second][0];
            T y = joint[connect[i].first][1] - constant[connect[i].second][1];
            T z = joint[connect[i].first][2] - constant[connect[i].second][2];

            score += x * x + y * y + z * z;
			++k;
        }
    }
    return sqrt(score / k);
}

#endif // RMSD_H
