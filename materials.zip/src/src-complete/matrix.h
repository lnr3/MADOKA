#ifndef MATRIX_H
#define MATRIX_H

#include "basic.h"

template <class T = double, class U = typename std::enable_if<std::is_arithmetic<T>::value, T>::type>
class Matrix
{
private:
    int row = 0;
    int column = 0;
    T *elem = nullptr;

    void check(int i, int j) const { if ((i < 0 || i >= row) || (j < 0 || j >= column)) throw std::out_of_range("matrix boundary exceeded"); }
public:
    using value_type = T;
    using size_type = int;
    using iterator = T*;
    using const_iterator = const T*;
    using reverse_iterator = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;

    Matrix(int d1, int d2) try : row(d1), column(d2), elem(new T[d1 * d2]{}) {}
    catch(...)
    {
        T *p = elem + row * column;
        for (; p != elem; --p)
            p->~T();
        delete [] elem;
        throw;
    }

    Matrix() = default;

    template <size_t M, size_t N>
    Matrix(const T (&a)[M][N]) : Matrix(M, N)
    {
        T *p = elem;
        for (int i = 0; i != M; ++i)
        {
            for (int j = 0; j != N; ++j)
                *p++ = a[i][j];
        }
    }

    Matrix(std::initializer_list<std::initializer_list<T>> l) : Matrix(l.size(), (l.begin())->size())
    {
        T *p = elem;
        for (auto i = l.begin(); i != l.end(); ++i)
        {
            for (auto j = i->begin(); j != i->end(); ++j)
                *p++ = *j;
        }
    }

    const int size() const noexcept {return row * column;}
    const int get_row() const noexcept {return row;}
    const int get_column() const noexcept {return column;}

    Matrix(const Matrix &);
    Matrix &operator=(const Matrix &);

    Matrix(Matrix &&) noexcept;
    Matrix &operator=(Matrix &&) noexcept;
    ~Matrix() {delete [] elem;}

    T &operator()(int x, int y) { check(x, y); return *(elem + x * column + y);}
    const T &operator()(int x, int y) const { check(x, y); return *(elem + x * column + y);}

    Matrix &operator+=(const Matrix &);
    Matrix &operator-=(const Matrix &);
    Matrix &operator*=(const T &);
    Matrix &operator*=(const Matrix &);

    void swap_rows(int, int);

    iterator begin() noexcept {return elem;}
    const_iterator begin() const noexcept {return elem;}
    const_iterator cbegin() const noexcept {return elem;}
    iterator end() noexcept {return elem + row * column;}
    const_iterator end() const noexcept {return elem + row * column;}
    const_iterator cend() const noexcept {return elem + row * column;}

    reverse_iterator rbegin() noexcept {return reverse_iterator(end());}
    const_reverse_iterator rbegin() const noexcept {return reverse_iterator(end());}
    const_reverse_iterator crbegin() const noexcept {return const_reverse_iterator(cend());}
    reverse_iterator rend() noexcept {return reverse_iterator(begin());}
    const_reverse_iterator rend() const noexcept {return reverse_iterator(begin());}
    const_reverse_iterator crend() const noexcept {return const_reverse_iterator(cbegin());}
};

template <class T, class U>
Matrix<T, U>::Matrix(const Matrix &m) : row(m.row), column(m.column), elem(new T[m.size()])
{
    std::uninitialized_copy(m.elem, m.elem + m.size(), elem);
}

template <class T, class U>
Matrix<T, U>& Matrix<T, U>::operator=(const Matrix &m)
{
    Matrix temp(m);
    std::swap(temp, *this);
    return *this;
}

template <class T, class U>
Matrix<T, U>::Matrix(Matrix &&m) noexcept : row(m.row), column(m.column), elem(m.elem)
{
    m.elem = nullptr;
}

template <class T, class U>
Matrix<T, U> &Matrix<T, U>::operator=(Matrix &&m) noexcept
{
    std::swap(row, m.row);
    std::swap(column, m.column);
    std::swap(elem, m.elem);
    return *this;
}

template <class T, class U>
Matrix<T, U> &Matrix<T, U>::operator+=(const Matrix &b)
{
    if (row != b.row || column != b.column)
        throw std::runtime_error("unequal matrix size in +");
    int n = size();
    for (int i = 0; i != n; ++i)
        elem[i] += b.elem[i];
    return *this;
}

template <class T, class U>
Matrix<T, U> &Matrix<T, U>::operator-=(const Matrix &b)
{
    if (row != b.row || column != b.column)
        throw std::runtime_error("unequal matrix size in -");
    int n = size();
    for (int i = 0; i != n; ++i)
        elem[i] -= b.elem[i];
    return *this;
}

template <class T, class U>
Matrix<T, U> &Matrix<T, U>::operator*=(const T &t)
{
    int n = size();
    for (int i = 0; i != n; ++i)
        elem[i] *= t;
    return *this;
}

template <class T, class U>
Matrix<T, U> &Matrix<T, U>::operator*=(const Matrix &b)
{
    if (column != b.row)
        throw std::runtime_error("invalid matrix size for multiply");
    Matrix m(row, b.column);
    for (int i = 0; i != row; ++i)
    {
        for (int j = 0; j != b.column; ++j)
        {
            T temp{};
            for (int k = 0; k != column; ++k)
                temp += this->operator()(i, k) * b(k, j);
            m(i, j) = temp;
        }
    }
    std::swap(m, *this);
    return *this;
}

template <class T, class U>
void Matrix<T, U>::swap_rows(int i, int j)
{
    if (i == j)
        return;
    if (i < 0 || i >= row || j < 0 || j >= row)
        throw std::runtime_error("invalid matrix row index");
    for (int n = 0; n != column; ++n)
        std::swap(*(elem + i * column + n), *(elem + j * column + n));
}

template <class T>
inline Matrix<T> operator+(const Matrix<T> &a, const Matrix<T> &b) {return Matrix<T>(a) += b;}

template <class T>
inline Matrix<T> operator-(const Matrix<T> &a, const Matrix<T> &b) {return Matrix<T>(a) -= b;}

template <class T>
inline Matrix<T> operator*(const Matrix<T> &a, const T &t) {return Matrix<T>(a) *= t;}

template <class T>
inline Matrix<T> operator*(const T &t, const Matrix<T> &a) {return a * t;}

template <class T>
inline Matrix<T> operator*(const Matrix<T> &a, const Matrix<T> &b) {return Matrix<T>(a) *= b;}

template <class T>
Matrix<T> transpose(const Matrix<T> &m)
{
    Matrix<T> m1{m.get_column(), m.get_row()};
    for (int i = 0; i != m.get_row(); ++i)
    {
        for (int j = 0; j != m.get_column(); ++j)
            m1(j, i) = m(i, j);
    }
    return m1;
}

template <class T>
std::ostream &operator<<(std::ostream &output, const Matrix<T> &a)
{
    for (int i = 0; i != a.get_row(); ++i)
    {
        output << '[';
        for (int j = 0; j != a.get_column(); ++j)
        {
            output << a(i, j);
            if (j != a.get_column() - 1)
                output << ", ";
        }
        output << ']';
        if (i != a.get_row() - 1)
            output << ", ";
        output << '\n';
    }
    return output;
}

template <class T>
std::istream &operator>>(std::istream &input, Matrix<T> &a)
{
    for (int i = 0; i != a.get_row(); ++i)
    {
        for (int j = 0; j != a.get_column(); ++j)
            input >> a(i, j);
    }
    return input;
}

template <class T>
T det(const Matrix<T> &m)
{
    auto A = m;
    const int n = A.get_column();
    int count = 0;

    for (int j = 0; j < n - 1; ++j)
    {
        int pivot_row = j;

        for (int k = j + 1; k < n; ++k)
        {
            if (abs(A(k, j)) > abs(A(pivot_row, j)))
                pivot_row = k;
        }

        if (pivot_row != j)
        {
            A.swap_rows(j, pivot_row);
            ++count;
        }

        for (int i = j + 1; i < n; ++i)
        {
            const T pivot = A(j, j);
            if (pivot == 0)
                return 0;
            const T mult = A(i, j) / pivot;

            for (int m = 0; m < n; ++m)
                A(i, m) -= mult * A(j, m);
        }
    }

    T t = A(0, 0);
    for (int i = 1; i != n; ++i)
        t *= A(i, i);
    return count & 1 ? -t : t;
}

template <class T>
void classical_elimination(Matrix<T> &A, std::vector<T> &b)
{
    const int n = A.get_column();

    for (int j = 0; j < n - 1; ++j)
    {
        int pivot_row = j;

        for (int k = j + 1; k < n; ++k)
        {
            if (abs(A(k, j)) > abs(A(pivot_row, j)))
                pivot_row = k;
        }

        if (pivot_row != j)
        {
            A.swap_rows(j, pivot_row);
            std::swap(b[j], b[pivot_row]);
        }

        for (int i = j + 1; i < n; ++i)
        {
            const T pivot = A(j, j);
            if (pivot == 0)
                throw std::runtime_error("can't solve: pivot == 0");
            const T mult = A(i, j) / pivot;

            for (int m = 0; m < n; ++m)
                A(i, m) -= mult * A(j, m);
            b[i] -= mult * b[j];
        }
    }
}

/** 代入 */
template <class T>
std::vector<T> back_substitution(const Matrix<T> &A, const std::vector<T> &b)
{
    int n = A.get_row();
    int m = A.get_column();
    std::vector<T> x(n);
    for (int i = n - 1; i >= 0; --i)
    {
        T sum;
        for (int j = i + 1; j != m; ++j)
            sum += A(i, j) * x[i + 1];
        if (T m = A(i, i))
            x[i] = (b[i] - sum) / m;
        else
            throw std::runtime_error("back substitution failure");
    }
    return x;
}

template <class T>
std::vector<T> gaussian_elimination(Matrix<T> A, std::vector<T> b)
{
    classical_elimination(A, b);
    return back_substitution(A, b);
}

#endif // MATRIX_H
