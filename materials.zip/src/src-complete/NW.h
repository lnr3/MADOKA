#ifndef NW_H
#define NW_H

#include "matrix.h"

/** LCS alignment */
template <typename T, typename RandomAccessIterator>
T structure_dp(Matrix<T> &matrix,
RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2)
{
    static_assert(std::is_arithmetic<T>::value, "invalid type of matrix element");

    if (begin1 == end1 || begin2 == end2) return T();
    auto size1 = matrix.get_row(), size2 = matrix.get_column();
    auto p = begin1, q = begin2;

    matrix(0, 0) = 0;
    for (decltype(size1) i = 1; i != size1; ++i)
        matrix(i, 0) = 0;
    for (decltype(size2) j = 1; j != size2; ++j)
        matrix(0, j) = 0;
    for (int i = 1; i != size1; ++i)
    {
        for (int j = 1; j != size2; ++j)
        {
            if (*p == *q)
                matrix(i, j) = matrix(i - 1, j - 1) + 1;
            else
                matrix(i, j) = std::max(matrix(i - 1, j), matrix(i, j - 1));
            ++q;
        }
        ++p;
        q = begin2;
    }
    return matrix(size1 - 1, size2 - 1);
}

/** LCS traceback */
template <typename T, typename RandomAccessIterator, typename OutputIterator, typename U = typename std::iterator_traits<RandomAccessIterator>::value_type>
void structure_alignment(const Matrix<T> &matrix, U blank,
RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2, OutputIterator output)
{
    static_assert(std::is_arithmetic<T>::value, "invalid type of matrix element");

    if (begin1 == end1 || begin2 == end2) return;
    auto i = matrix.get_row() - 1, j = matrix.get_column() - 1;
    auto p = --end1, q = --end2;

    while (i > 0 && j > 0)
    {
        if (matrix(i, j) > matrix(i - 1, j - 1) && matrix(i, j) > matrix(i, j - 1) && matrix(i, j) > matrix(i - 1, j))
        {
            *output = {*p, *q};
            --i, --j;
            --p, --q;
        }
        else if (matrix(i, j - 1) > matrix(i - 1, j))
        {
            *output = {blank, *q};
            --j;
            --q;
        }
        else
        {
            *output = {*p, blank};
            --i;
            --p;
        }
        ++output;
    }
}

/** DP based on kabsch rotation */
template <typename T, typename RandomAccessIterator, typename BinaryPredicate>
void residue_dp(Matrix<T> &matrix, T gap,
RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2,
BinaryPredicate pred)
{
    static_assert(std::is_arithmetic<T>::value, "invalid type of matrix element");

    if (begin1 == end1 || begin2 == end2) return;
    auto size1 = matrix.get_row(), size2 = matrix.get_column();
    auto p = begin1, q = begin2;

    matrix(0, 0) = 0;
    for (decltype(size1) i = 1; i != size1; ++i)
        matrix(i, 0) = 0;
    for (decltype(size2) j = 1; j != size2; ++j)
        matrix(0, j) = 0;

    for (decltype(size1) i = 1; i != size1; ++i)
    {
        for (decltype(size2) j = 1; j != size2; ++j)
        {
            matrix(i, j) = std::max({matrix(i - 1, j - 1) + pred(*p, *q), matrix(i - 1, j) + gap, matrix(i, j - 1) + gap});
            ++q;
        }
        ++p;
        q = begin2;
    }
}

/** traceback based on kabsch rotation */
template <typename T, typename RandomAccessIterator, typename OutputIterator, typename BinaryPredicate>
void residue_alignment(const Matrix<T> &matrix, T gap,
RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2,
OutputIterator output, BinaryPredicate pred)
{
    static_assert(std::is_arithmetic<T>::value, "invalid type of matrix element");

    if (begin1 == end1 || begin2 == end2) return;
    auto i = matrix.get_row() - 1, j = matrix.get_column() - 1;
    auto p = --end1, q = --end2;

    while (i > 0 && j > 0)
    {
        if (matrix(i, j) == matrix(i - 1, j - 1) + pred(*p, *q))
        {
            *output = {i - 1, j - 1};
            --i, --j;
            --p, --q;
        }
        else if (matrix(i, j) == matrix(i - 1, j) + gap)
        {
            *output = {i - 1, -1};
            --i;
            --p;
        }
        else
        {
            *output = {-1, j - 1};
            --j;
            --q;
        }
        ++output;
    }
}

#endif // NW_H
