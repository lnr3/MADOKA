#include "prepare.h"

bool duplicate(int number, char **file) noexcept
{
    for (int i = 0; i != number - 1; ++i)
    {
        for (int j = i + 1; j != number; ++j)
            if (strcmp(file[i], file[j]) == 0) return true;
    }
    return false;
}
