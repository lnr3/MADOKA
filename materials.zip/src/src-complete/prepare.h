#ifndef PREPARE_H
#define PREPARE_H

#include "basic.h"

/** is there any duplicate input file? */
bool duplicate(int, char **) noexcept;

#endif // PREPARE_H
