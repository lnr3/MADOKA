#include "residue.h"

char AAmap(const char *AA)
{
    if (strcmp(AA, "ALA") == 0) return 'A';
    if (strcmp(AA, "ARG") == 0) return 'R';
    if (strcmp(AA, "ASP") == 0) return 'D';
    if (strcmp(AA, "CYS") == 0) return 'C';
    if (strcmp(AA, "GLN") == 0) return 'Q';
    if (strcmp(AA, "GLU") == 0) return 'E';
    if (strcmp(AA, "HIS") == 0) return 'H';
    if (strcmp(AA, "ILE") == 0) return 'I';
    if (strcmp(AA, "GLY") == 0) return 'G';
    if (strcmp(AA, "ASN") == 0) return 'N';
    if (strcmp(AA, "LEU") == 0) return 'L';
    if (strcmp(AA, "LYS") == 0) return 'K';
    if (strcmp(AA, "MET") == 0) return 'M';
    if (strcmp(AA, "PHE") == 0) return 'F';
    if (strcmp(AA, "PRO") == 0) return 'P';
    if (strcmp(AA, "SER") == 0) return 'S';
    if (strcmp(AA, "THR") == 0) return 'T';
    if (strcmp(AA, "TRP") == 0) return 'W';
    if (strcmp(AA, "TYR") == 0) return 'Y';
    if (strcmp(AA, "VAL") == 0) return 'V';
    throw std::invalid_argument(string("No amino acid name ") + AA);
}

const char *AAmap(char A)
{
    A = toupper(A);
    if (A == 'A') return "ALA";
    if (A == 'R') return "ARG";
    if (A == 'D') return "ASP";
    if (A == 'B' || A == 'C' || A == 'J' || A == 'O' || A == 'Z') return "CYS";
    if (A == 'Q') return "GLN";
    if (A == 'E') return "GLU";
    if (A == 'H') return "HIS";
    if (A == 'I') return "ILE";
    if (A == 'G') return "GLY";
    if (A == 'N') return "ASN";
    if (A == 'L') return "LEU";
    if (A == 'K') return "LYS";
    if (A == 'M') return "MET";
    if (A == 'F') return "PHE";
    if (A == 'P') return "PRO";
    if (A == 'S') return "SER";
    if (A == 'T') return "THR";
    if (A == 'W') return "TRP";
    if (A == 'Y') return "TYR";
    if (A == 'V') return "VAL";
    throw std::invalid_argument(string("No amino acid name ") + A);
}
