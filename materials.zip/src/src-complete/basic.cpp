#include "basic.h"

extern const unsigned int threads = std::thread::hardware_concurrency();

unsigned int tasks = std::thread::hardware_concurrency();

const char *directory = nullptr;

string filename_process(const char *p, const char *q)
{
    if (p == nullptr || q == nullptr)
        return "";

    string file(directory);
    for (int i = 0; p[i] && p[i] != '.'; ++i)
        file.push_back(p[i]);
    file.push_back('-');
    for (int i = 0; q[i] && q[i] != '.'; ++i)
        file.push_back(q[i]);

    file += "-result.txt";
    return file;
}
