#ifndef BASIC_H
#define BASIC_H

#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <cstring>

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <stdexcept>
#include <iterator>
#include <utility>
#include <tuple>
#include <initializer_list>
#include <type_traits>
#include <functional>

#include <chrono>
#include <thread>
#include <future>

using std::vector; using std::string; using std::to_string;
using std::pair; using std::tuple; using std::get;
using std::cout; using std::cerr; using std::ifstream; using std::ofstream;
using std::future;
using namespace std::chrono;

extern const unsigned int threads;

extern unsigned int tasks;

extern const char *directory;

string filename_process(const char *, const char *);

#endif // BASIC_H
