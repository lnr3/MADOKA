#include "unit.h"

std::multimap<const char *, const char *> permutation(int number, char **file, int &n, char **&f)
{
    std::multimap<const char *, const char *> paired;
    // -s for one-to-many alignments
    if (strcmp(*file, "-s") == 0)
    {
        n -= 3;
        f += 3;
        directory = file[2];
        for (int i = 4; i != number; ++i)
            paired.insert({file[3], file[i]});
    }
    else
    {
        // all-against-all alignments
        n -= 2;
        f += 2;
        directory = file[1];
        for (int i = 2; i != number - 1; ++i)
        {
            for (int j = i + 1; j != number; ++j)
                paired.insert({file[i], file[j]});
        }
    }
    return paired;
}

vector<string> read_all_structure(int number, char **file)
{
    vector<string> structures;
    int i = 0;
    if (strcmp(*file, "-s") == 0) i = 3;
    else i = 2;
    for (; i != number; ++i)
    {
        string s;
        s.reserve(space);
        read_structure(file[i], std::back_inserter(s));
        structures.push_back(std::move(s));
    }
    return structures;
}
