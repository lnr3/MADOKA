#ifndef UNIT_H
#define UNIT_H

#include "initial.h"
#include "accurate.h"

/** the complete step for a pair of proteins */
template <typename T>
tuple<T, T, int, int> pairwise(const string &A, const string &B, const char *p, const char *q)
{
    string file = filename_process(p, q);
    if (first_phase(A, B, p, q, file))
        return second_phase<T>(p, q, file);
    else
        return std::make_tuple(0.0, 0.0, 0, 0);
}

template <typename T, typename ForwardIterator>
tuple<T, T, int, int, int> parallel_pairwise(ForwardIterator begin, ForwardIterator end, int n, char **f, const vector<string> &s)
{
    tuple<T, T, int, int> average;
    int m = 0;
    for (auto iterator = begin; iterator != end; ++iterator)
    {
        unsigned int i = std::find(f, f + n, iterator->first) - f;
        unsigned int j = std::find(f, f + n, iterator->second) - f;
        tuple<T, T, int, int> single = pairwise<T>(s[i], s[j], iterator->first, iterator->second);
        if (get<0>(single) != 0.0)
        {
            ++m;
            get<0>(average) += get<0>(single);
            get<1>(average) += get<1>(single);
            get<2>(average) += get<2>(single);
            get<3>(average) += get<3>(single);
        }
    }
    return std::make_tuple(get<0>(average), get<1>(average), get<2>(average), get<3>(average), m);
}

std::multimap<const char *, const char *> permutation(int, char **, int &, char ** &);

vector<string> read_all_structure(int, char **);

/** sequential or parallel computing? */
template <typename T>
tuple<T, T, T, T> trunk(int number, char **file)
{
    int n = number;
    char **f = file;
    auto composition = permutation(number, file, n, f);
    auto structures = read_all_structure(number, file);

    unsigned int size = composition.size();
    if (size < 2 * threads || threads < 2)
    {
        tuple<T, T, int, int> average;
        int m = 0;
        for (auto iterator = std::begin(composition); iterator != std::end(composition); ++iterator)
        {
            unsigned int i = std::find(f, f + n, iterator->first) - f;
            unsigned int j = std::find(f, f + n, iterator->second) - f;
            tuple<T, T, int, int> single = pairwise<T>(structures[i], structures[j], iterator->first, iterator->second);
            if (get<0>(single) != 0.0)
            {
                ++m;
                get<0>(average) += get<0>(single);
                get<1>(average) += get<1>(single);
                get<2>(average) += get<2>(single);
                get<3>(average) += get<3>(single);
            }
        }
        if (m != 0)
            return std::make_tuple(get<0>(average) / m, get<1>(average) / m, get<2>(average) / double(m), get<2>(average) / double(get<3>(average)));
        return std::make_tuple(0.0, 0.0, 0.0, 0.0);
    }

    tasks = 1;
    vector<future<tuple<T, T, int, int, int>>> vec1(threads);
    vector<tuple<T, T, int, int, int>> vec2;
    unsigned int sum = 0, each = 0;
    auto begin = std::begin(composition), end = begin;
    for (unsigned int i = 0; i != threads; ++i)
    {
        each = (size - sum) / (threads - i);
        for (unsigned int j = 0; j != each; ++j)
            ++end;
        vec1[i] = std::async(std::launch::async, parallel_pairwise<T, decltype(begin)>, begin, end, n, f, std::cref(structures));
        begin = end;
        sum += each;
    }
    for (auto ite = vec1.rbegin(), end = vec1.rend(); ite != end; ++ite)
        vec2.push_back(ite->get());
    tuple<T, T, int, int> average;
    int m = 0;
    for (unsigned int i = 0; i != threads; ++i)
    {
        get<0>(average) += get<0>(vec2[i]);
        get<1>(average) += get<1>(vec2[i]);
        get<2>(average) += get<2>(vec2[i]);
        get<3>(average) += get<3>(vec2[i]);
        m += get<4>(vec2[i]);
    }
    if (m != 0)
        return std::make_tuple(get<0>(average) / m, get<1>(average) / m, get<2>(average) / double(m), get<2>(average) / double(get<3>(average)));
    return std::make_tuple(0.0, 0.0, 0.0, 0.0);
}

#endif // UNIT_H
