#ifndef RESIDUE_H
#define RESIDUE_H

#include "basic.h"

template <typename T>
struct Residue
{
    char kind;
    T coordinate[3];

    T  operator[](int i) const {return coordinate[i];}
    T &operator[](int i) {return coordinate[i];}

    operator char() const noexcept {return kind;}
};

constexpr double PENALTY_R = 3e-6;

constexpr int space = 100;

constexpr int pairs = 180;

/** use for rotation matrix scoring */
template <typename T>
class Similarity
{
public:
    T d0;
    Similarity(T lmin) : d0(1.24 * cbrt(lmin - 15) - 1.8) { d0 *= d0;}
    T operator() (const Residue<T> &r1, const Residue<T> &r2) const
    {
        T x = r1[0] - r2[0];
        T y = r1[1] - r2[1];
        T z = r1[2] - r2[2];

        T di = x * x + y * y + z * z;
        return 1.0 / (1.0 + (di / d0));
    }
};

char AAmap(const char *);

const char *AAmap(char);

#endif // RESIDUE_H
