#ifndef READ_H
#define READ_H

#include "basic.h"
#include "residue.h"

/** read coordinates of residues from .sse file */
template <typename T, typename OutputIterator>
void read_residue(const char *file, OutputIterator output)
{
    ifstream input(file);
    if (!input) throw std::invalid_argument(string("no such file named ") + file);
    input.seekg(2, std::ios::beg);
    char c = 0;
    while ((c = input.get()) != '#')
        input.seekg(128, std::ios::cur);
    input.seekg(134, std::ios::cur);
    input.seekg(14, std::ios::cur);

    char A = 0;
    T x = 0, y = 0, z = 0;
    while ((A = input.get()) != EOF)
    {
        if (A == '!')
        {
            char ch = input.get();
            if (ch == '*')
                break;
            else
            {
                input.seekg(135, std::ios::cur);
                continue;
            }
        }
        input.seekg(103, std::ios::cur);
        input >> x >> y >> z;
        *output = Residue<T>{A, {x, y, z}};
        ++output;
        input.seekg(14, std::ios::cur);
    }
    input.close();
}

/** read secondary structure elements of residues from .sse file */
template <typename OutputIterator>
void read_structure(const char *file, OutputIterator output)
{
    ifstream input(file);
    if (!input) throw std::invalid_argument(string("no such file named ") + file);
    input.seekg(2, std::ios::beg);
    char c = 0;
    while ((c = input.get()) != '#')
        input.seekg(128, std::ios::cur);
    input.seekg(134, std::ios::cur);
    input.seekg(14, std::ios::cur);

    char current = 0, chain = 0;
    while ((chain = input.get()) != EOF)
    {
        if (chain == '!')
        {
            char ch = input.get();
            if (ch == '*')
                break;
            else
                input.putback(ch);
        }
        input.seekg(2, std::ios::cur);
        current = input.get();
        if (current != ' ')
        {
            *output = current;
            ++output;
        }
        input.seekg(133, std::ios::cur);
    }
}

#endif // READ_H
