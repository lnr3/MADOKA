#ifndef INITIAL_H
#define INITIAL_H

#include "readfile.h"
#include "writefile.h"
#include "matrix.h"
#include "NW.h"

/** initial alignment */
bool first_phase(const string &, const string &, const char *, const char *, const string &);

#endif // INITIAL_H
