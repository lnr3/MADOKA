#ifndef ACCURATE_H
#define ACCURATE_H

#include "readfile.h"
#include "writefile.h"
#include "matrix.h"
#include "NW.h"
#include "kabsch.h"
#include "tmscore.h"
#include "rmsd.h"

/** fundamental function of the accurate alignment */
template <typename T, typename RandomAccessIterator>
tuple<vector<Residue<T>>, vector<pair<int, int>>> single_compare(RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2)
{
    T rms;
    T t[3];
    T u[3][3];

    int x = end1 - begin1;
    Similarity<T> tm(x);

    vector<Residue<T>> A(begin1, end1), C;
    vector<pair<int, int>> init, optimal;
    init.reserve(pairs);
    optimal.reserve(pairs);
    Matrix<T> score(x + 1, x + 1);  // DP matrix

    const int sequence = 10;
    kabsch(A.cbegin(), A.cend(), begin2, end2, 1, &rms, t, u);
    do_rotation(A.begin(), A.end(), begin1, end1, t, u);
    C = A;

    // second phase alignment
    residue_dp(score, PENALTY_R, A.cbegin(), A.cend(), begin2, end2, tm);
    residue_alignment(score, PENALTY_R, A.cbegin(), A.cend(), begin2, end2, std::back_inserter(init), tm);
    std::reverse(init.begin(), init.end());

    // collect all aligned fragments at least with 10 successive aligned residues and make a superpose again
    int n = 0;
    int size = init.size();
    for (int k = 0; k != size; )
    {
        if (init[k].first != -1 && init[k].second != -1)
        {
            n = k++;
            for (; k != size; ++k)
            {
                if (init[k].first == -1 || init[k].second == -1)
                    break;
            }
            int m = k - n;
            if (sequence <= m)
            {
                auto start1 = A.cbegin() + init[n].first;
                auto start2 = begin2 + init[n].second;
                kabsch(start1, start1 + m, start2, start2 + m, 1, &rms, t, u);
                auto start3 = A.begin() + init[n].first;
                auto start4 = C.cbegin() + init[n].first;
                do_rotation(start3, start3 + m, start4, start4 + m, t, u);
            }
        }
        else
            ++k;
    }
    residue_dp(score, PENALTY_R, A.cbegin(), A.cend(), begin2, end2, tm);
    residue_alignment(score, PENALTY_R, A.cbegin(), A.cend(), begin2, end2, std::back_inserter(optimal), tm);
    std::reverse(optimal.begin(), optimal.end());
    return std::make_tuple(std::move(A), std::move(optimal));   // superposed short chain and the complete alignment
}

/** the gapless threading between the short chain and the long chain */
template <typename T, typename RandomAccessIterator>
tuple<T, T, int, vector<pair<int, int>>> compare(RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2, int part)
{
    int x = end1 - begin1, y = end2 - begin2;
    if (x < part * 10 && part > 1)
        return std::make_tuple(0, 0, 0, vector<pair<int, int>>());
    int iteration = y - x + 1;
    T t1 = 0, t2 = 0, r1 = 0, r2 = 0;
    int z = 0;
    vector<tuple<vector<Residue<T>>, vector<pair<int, int>>>> local(part);
    vector<pair<int, int>> ultimate;
    for (int i = 0; i != iteration; ++i)
    {
        auto begin3 = begin2 + i;
        int sum = 0;
        // divides the short chain into several parts
        for (int j = 0; j != part; ++j)
        {
            int each = (x - sum) / (part - j);
            local[j] = single_compare<T>(begin1 + sum, begin1 + sum + each, begin3 + sum, begin3 + sum + each);
            for (auto &p : get<1>(local[j]))
            {
                if (p.first != -1)
                    p.first += sum;
                if (p.second != -1)
                    p.second += sum;
            }
            sum += each;
        }
        vector<Residue<T>> joint;
        vector<pair<int, int>> connect;
        for (int j = 0; j != part; ++j)
        {
            const auto &single1 = get<0>(local[j]);
            joint.insert(joint.end(), single1.cbegin(), single1.cend());

            const auto &single2 = get<1>(local[j]);
            connect.insert(connect.end(), single2.cbegin(), single2.cend());
        }
        // choose the local optimal position on the long chain with highest TM-score
        t1 = tmscore<T>(joint.cbegin(), begin3, connect, x);
        r1 = rmsd<T>(joint.cbegin(), begin3, connect, x);
        if (t2 < t1)
        {
            t2 = t1;
            r2 = r1;
            z = i;

            ultimate = connect;
        }
    }
	for (auto &p : ultimate)
    {
		if (p.second != -1)
         	p.second += z;
    }
    return std::make_tuple(t2, r2, z, std::move(ultimate));
}

/** compute the global optimal alignment with a given number of parts and decide to use sequential or parallel */
template <typename T, typename RandomAccessIterator>
tuple<T, T, int, vector<pair<int, int>>> parallel_compare(RandomAccessIterator begin1, RandomAccessIterator end1, RandomAccessIterator begin2, RandomAccessIterator end2, int part)
{
    int x = end1 - begin1, y = end2 - begin2;
    if (x > y) throw std::runtime_error("order reversed");

    unsigned int iteration = y - x + 1;
    if (iteration < 2 * tasks || tasks < 2) return compare<T>(begin1, end1, begin2, end2, part);

    // parallel computing on CPU
    vector<future<tuple<T, T, int, vector<pair<int, int>>>>> futures(tasks);
    vector<unsigned int> start(tasks);
    unsigned int sum = 0;
    unsigned int each = 0;
    for (unsigned int i = 0; i != tasks; ++i)
    {
        each = (iteration - sum) / (tasks - i);
        start[i] = sum;
        futures[i] = std::async(std::launch::async, compare<T, RandomAccessIterator>, begin1, end1, begin2 + sum, begin2 + sum + (x + each - 1), part);
        sum += each;
    }
    vector<tuple<T, T, int, vector<pair<int, int>>>> results(tasks);
    for (unsigned int i = 0; i != tasks; ++i)
        results[i] = futures[i].get();
    auto best = std::max_element(results.begin(), results.end(),
    [] (const tuple<T, T, int, vector<pair<int, int>>> &t1, const tuple<T, T, int, vector<pair<int, int>>> &t2)
    { return get<0>(t1) < get<0>(t2); });

    unsigned int position = start[best - results.begin()];
    get<2>(*best) += position;

    for (auto &p : get<3>(*best))
    {
        if (p.second != -1)
            p.second += position;
    }
    return std::move(*best);    // choose the global optimal position on the long chain with highest TM-score
}

/** output the result of accurate alignment into a file */
template <typename T>
void output(const string &file, const char *f1, const char *f2, const tuple<T, T, int, vector<pair<char, char>>> &result, int length)
{
    int n = 0;
    for (pair<char, char> p : get<3>(result))
    {
        if (p.first != '-' && p.second != '-')
            ++n;
    }

    const auto &align = get<3>(result);
    string remark1 = f2;
    remark1 += " index " + to_string(get<2>(result) + 1);
    remark1 += "\nsequence length " + to_string(length);
    remark1 += "\naligned length " + to_string(n);
    string remark2 = "\nTM-score " + to_string(get<0>(result)) + "\nRMSD " + to_string(get<1>(result)) + "\n\n";
    remark2 += string(f1) + "-" + f2;
    write_result(file.data(), remark1 + remark2, align.cbegin(), align.cend());
}

/** accurate alignment */
template <typename T>
tuple<T, T, int, int> second_phase(const char *p1, const char *p2, const string &file)
{
    vector<Residue<T>> A, B;
    A.reserve(space);
    B.reserve(space);

    read_residue<T>(p1, std::back_inserter(A));
    read_residue<T>(p2, std::back_inserter(B));

    // A as the template and B as the constant
    int x = A.size(), y = B.size();
    const char *f1 = p1, *f2 = p2;
    if (y < x)
    {
        A.swap(B);
        std::swap(x, y);
        std::swap(f1, f2);
    }

    tuple<T, T, int, vector<pair<int, int>>> r1, r2;
    T t1 = 0, t2 = 0;
    double d = 1;
    for (int i = 1; i != 12; )
    {
        r1 = parallel_compare<T>(A.cbegin(), A.cend(), B.cbegin(), B.cend(), i);
        t1 = get<0>(r1);
        if (t1 == 0)
            break;
        if (t2 < t1)
        {
            t2 = t1;
            r2 = r1;
        }
        d *= 1.5;
        i = ceil(d);
        d = i;
    }
    const vector<pair<int, int>> &align = get<3>(r2);
    vector<pair<char, char>> simple;

    int m = 0, n = align.size();    // m as the number of aligned residues
    for (const auto &p : align)
    {
        if (p.first == -1)
            simple.push_back({'-', B[p.second]});
        else if (p.second == -1)
            simple.push_back({A[p.first], '-'});
        else
        {
            simple.push_back({A[p.first], B[p.second]});
            ++m;
        }
    }

    output(file, f1, f2, std::make_tuple(get<0>(r2), get<1>(r2), get<2>(r2), std::move(simple)), x);
    return std::make_tuple(get<0>(r2), get<1>(r2), m, n);
}

#endif // ACCURATE_H
