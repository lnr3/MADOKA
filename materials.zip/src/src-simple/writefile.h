#ifndef WRITEFILE_H
#define WRITEFILE_H

#include "basic.h"
#include "residue.h"

// output the result
template <typename ForwardIterator>
void write_result(const char *file, const string &remark, ForwardIterator begin, ForwardIterator end)
{
    ofstream output(file, std::ios::app);
    if (!output) throw std::runtime_error("file writing failed");

    output << remark << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
        output << iterator->first;
    output << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
    {
        if (iterator->first == '-' || iterator->second == '-')
            output << ' ';
        else
            output << '|';
    }
    output << '\n';
    for (auto iterator = begin; iterator != end; ++iterator)
        output << iterator->second;
    output << "\n\n";
    output.close();
}

#endif // WRITEFILE_H
